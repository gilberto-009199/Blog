package org.voayger;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import static java.lang.System.out;

public class Main {

	public static void main(String[] args) {
		
		Main knn = new Main();
		List<Cliente> lista = knn.le_arquivo("mediaPorNasci.knn.algoritmo.txt");
		// Pegando os dados 
		List<Cliente> listClassificados = knn.le_arquivo("mediaPorNasci.knn.algoritmo.txt");
		List<Cliente> listNaoClassificados = knn.le_arquivo("comandas.knn.algoritmo.txt");
		
		
		out.println(listClassificados);
		// Variaveis Acumuladoras de cada nacionalidade
		int qtdAmericanos = 0;
		int qtdEspanhol = 0;
		int qtdFrances = 0;
		int qtdBrasileiro = 0;

		for(Cliente clienteNaoIdentificado : listNaoClassificados){
			// Lista que ira ordenarar as pessoa mais proximos dele 
		    Map<Double,String> listIndexadaPelaDistancia = new TreeMap<Double,String>();
		    
		    for(Cliente pessoaIdentificada : listClassificados){
		    	// Comparando e pegando a distancia
		        Double distancia = getEuclidiana(clienteNaoIdentificado,pessoaIdentificada);
		        // Colocando na lista de ordenacao
		        listIndexadaPelaDistancia.put(distancia,pessoaIdentificada.nascionalidade);

		    }
		    int K = 7;
		    int contador = 0;
		    /*
		       Escolhi 7, mas na minha opniao seria melhor
		      pegar uma porcentagem dos classificados como 30% algo assim,
		      quem sabe , afinal eu não sou um experti em algoritmos de 
		      aprendizado supervisionado de maguina 
		    */
		    int isAmerica = 0;
		    int isFrances = 0;
		    int isEspanho = 0;
		    int isBrasile = 0;
		    for(Double key : listIndexadaPelaDistancia.keySet()) {
		    	// Codigo que verifica qual nascionalidade é predominate
		    	if (listIndexadaPelaDistancia.get(key).equals("America"))
		            isAmerica += 1;
		        else if(listIndexadaPelaDistancia.get(key).equals("Espanho"))
		            isEspanho += 1;
		        else if(listIndexadaPelaDistancia.get(key).equals("Frances"))
		            isFrances += 1;
		        else if(listIndexadaPelaDistancia.get(key).equals("Brasile"))
		            isBrasile += 1;
		        else out.println("Categoria não identificada");
		    	
	    	   if(contador < K)contador++;
	    	   else break;
	    	}
		    
		    String categoriaDefinida = "Indefinida...";
		    // IFs apra verificar qual nacionalidade esta mais presente
		    if(isAmerica>isEspanho && isAmerica > isFrances && isAmerica> isBrasile)
		    {
		        categoriaDefinida = "America";
		        qtdAmericanos += 1;
		    }
		    else if(isEspanho>isAmerica && isEspanho>isFrances && isEspanho> isBrasile)
		    {
		        categoriaDefinida = "Espanho";
		        qtdEspanhol += 1;
		    }
		    else if(isFrances>isAmerica && isFrances>isEspanho && isFrances> isBrasile)
		    {
		        categoriaDefinida = "Frances";
		        qtdFrances += 1;
		    }
		    else if(isBrasile>isAmerica && isBrasile>isEspanho && isBrasile>isFrances)
		    {
		        categoriaDefinida = "Brasile";
		        qtdBrasileiro += 1;
		    }

		    out.println("Categoria Definida   : " + categoriaDefinida);
		    out.println("Categoria Verdadeira : " + clienteNaoIdentificado.nascionalidade);
		    
		}
		
		out.println(" Nacionalidade dos clientes :");
		out.println(" Americanos "+ qtdAmericanos);
		out.println(" Espanhois  "+ qtdEspanhol);
		out.println(" Franceses  "+ qtdFrances);
		out.println(" Brasileiros  "+ qtdBrasileiro);
		
	}
	
	public static double getEuclidiana(Cliente cliente0 , Cliente cliente1){
	 /*
	      Distância euclidiana é a raiz quadrada da soma das
	     diferenças dos valores dos atributos elevado ao quadrado
	 */

	 double soma = 0;
	 soma+=Math.pow((cliente0.carnes_vermelhas - cliente1.carnes_vermelhas),2);
	 soma +=Math.pow((cliente0.carnes_brancas   - cliente1.carnes_brancas), 2);
	 soma +=Math.pow((cliente0.massas           - cliente1.massas        ), 2);
	 soma +=Math.pow((cliente0.frutas           - cliente1.frutas        ), 2);
	 soma +=Math.pow((cliente0.vegetais         - cliente1.vegetais      ), 2);

	 return Math.sqrt(soma);
	}
	
	public List<Cliente> le_arquivo(String nome){
	   // Lista com os dados pegos linha por linha
	   List<Cliente> listDados = new ArrayList<Cliente>();
	   try {
		   
	   BufferedReader arquivo = new BufferedReader(new  FileReader(nome));
	   String linha;
	   
		while ((linha = arquivo.readLine()) != null) {
			   System.out.println(linha);
			   Cliente client = new Cliente(); 
			     
		       client.carnes_vermelhas = Float.parseFloat(linha.substring( 4 , 9 ));
		       client.carnes_brancas   = Float.parseFloat(linha.substring( 13 , 18 ));
		       client.massas           = Float.parseFloat(linha.substring( 22 , 27 ));
		       client.frutas           = Float.parseFloat(linha.substring( 31 , 36 ));
		       client.vegetais         = Float.parseFloat(linha.substring( 40 , 45 ));
		       client.nascionalidade   = linha.substring( 50 , 57 );
			   // Monta o Cliente e adiciona na lista 
			   listDados.add(client);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   
	       

	    return listDados;
	}
	
	public class Cliente{
		public float carnes_vermelhas;
		public float carnes_brancas;
		public float massas;
		public float frutas;
		public float vegetais;
		public String nascionalidade;
		public Cliente() {}
	}
}
